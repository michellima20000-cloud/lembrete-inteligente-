import React, { useState, useEffect } from 'react';
import { Bell, BellOff, CheckCircle2, RotateCcw, X, Clock, AlertTriangle, Eye, Volume2 } from 'lucide-react';
import { useReminders } from '../context/RemindersContext';

export const ActiveAlarmModal: React.FC = () => {
  const { activeAlarmReminder, dismissAlarm, snoozeReminder, updateStatus, isRingingContinuous, silenceAlarm } =
    useReminders();

  const [hasInteracted, setHasInteracted] = useState(false);

  useEffect(() => {
    if (activeAlarmReminder) {
      setHasInteracted(false);
    }
  }, [activeAlarmReminder?.id]);

  if (!activeAlarmReminder) return null;

  const targetDate = new Date(activeAlarmReminder.data_hora_execucao);
  const timeFormatted = targetDate.toLocaleTimeString('pt-BR', {
    hour: '2-digit',
    minute: '2-digit',
  });
  const dateFormatted = targetDate.toLocaleDateString('pt-BR', {
    day: '2-digit',
    month: 'short',
  });

  const handleViewAndSilence = () => {
    silenceAlarm();
    setHasInteracted(true);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-in fade-in"
      onClick={handleViewAndSilence}
    >
      <div
        className="w-full max-w-sm rounded-3xl bg-slate-900 border-2 border-amber-500/90 p-6 shadow-2xl text-slate-100 shadow-amber-500/30 animate-in zoom-in-95"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Ringing bell icon header with live continuous sound indicator */}
        <div className="flex flex-col items-center text-center">
          <div className="relative mb-3 flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-tr from-amber-600 via-amber-500 to-yellow-400 shadow-2xl shadow-amber-500/50 animate-bounce">
            <Bell className="w-10 h-10 text-white animate-pulse" />
            <span className="absolute -top-1 -right-1 flex h-5 w-5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-90"></span>
              <span className="relative inline-flex rounded-full h-5 w-5 bg-rose-500 items-center justify-center text-[10px] text-white font-bold">
                !
              </span>
            </span>
          </div>

          {/* Continuous alarm badge */}
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/50 shadow-inner">
            {isRingingContinuous ? (
              <>
                <Volume2 className="w-3.5 h-3.5 animate-pulse text-amber-400" />
                <span>Tocando Direto até você ver!</span>
              </>
            ) : (
              <>
                <BellOff className="w-3.5 h-3.5 text-slate-400" />
                <span>Alarme em Visualização</span>
              </>
            )}
          </div>

          <h2 className="mt-3.5 text-lg font-black text-white leading-snug px-2">
            {activeAlarmReminder.titulo}
          </h2>

          <div className="flex flex-wrap items-center justify-center gap-2 mt-2.5 text-sm text-slate-300">
            <span className="flex items-center gap-1.5 bg-slate-800/80 px-3 py-1 rounded-xl border border-slate-700/60">
              <Clock className="w-4 h-4 text-amber-400" />
              <span>
                <strong>{timeFormatted}</strong> ({dateFormatted})
              </span>
            </span>
            {activeAlarmReminder.antecedencia_minutos > 0 && (
              <span className="text-xs text-amber-400 font-semibold bg-amber-950/40 border border-amber-500/30 px-2 py-1 rounded-xl">
                Aviso {activeAlarmReminder.antecedencia_minutos}m antes
              </span>
            )}
          </div>

          {activeAlarmReminder.categoria && (
            <span className="mt-2 text-xs px-2.5 py-0.5 rounded-lg bg-indigo-950/60 text-indigo-300 border border-indigo-500/30 font-medium">
              Categoria: {activeAlarmReminder.categoria}
            </span>
          )}

          <p className="mt-2 text-[11px] text-slate-400">
            Sintetizador de som nativo: 0% de uso de dados da sua internet.
          </p>
        </div>

        {/* Priority Actions */}
        <div className="mt-5 space-y-2.5">
          {/* Silenciar som se ainda estiver tocando */}
          {isRingingContinuous && (
            <button
              onClick={handleViewAndSilence}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-sm shadow-lg shadow-amber-500/30 active:scale-[0.98] transition"
            >
              <Eye className="w-4 h-4" />
              Visualizar & Silenciar Toque
            </button>
          )}

          {/* Concluir Agora */}
          <button
            onClick={() => updateStatus(activeAlarmReminder.id, 'concluído')}
            className="w-full flex items-center justify-center gap-2 py-3.5 px-4 rounded-2xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white font-bold text-sm shadow-lg shadow-emerald-600/30 active:scale-[0.98] transition"
          >
            <CheckCircle2 className="w-5 h-5" />
            Concluir Tarefa Agora
          </button>

          {/* Adiar 10 Minutos */}
          <button
            onClick={() => snoozeReminder(activeAlarmReminder.id, 10)}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-2xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/50 text-amber-300 font-bold text-sm shadow-md active:scale-[0.98] transition"
          >
            <RotateCcw className="w-4 h-4" />
            Adiar por 10 Minutos
          </button>

          {/* Dispensar */}
          <button
            onClick={dismissAlarm}
            className="w-full py-2 px-4 rounded-2xl text-slate-400 hover:text-white hover:bg-slate-800/80 text-xs font-semibold transition"
          >
            Fechar Janela
          </button>
        </div>
      </div>
    </div>
  );
};
