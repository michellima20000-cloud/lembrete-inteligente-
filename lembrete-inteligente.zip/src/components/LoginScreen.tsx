import React, { useState } from 'react';
import {
  ShieldCheck,
  Mail,
  Lock,
  User,
  AlertCircle,
  Check,
  ExternalLink,
  Flame,
  ArrowRight,
} from 'lucide-react';
import { useUser } from '../context/UserContext';
import { PWAInstallButton } from './PWAInstallButton';

export const LoginScreen: React.FC = () => {
  const {
    signInWithEmail,
    signUpWithEmail,
    sendPasswordReset,
    authError,
    clearAuthError,
  } = useUser();

  const [mode, setMode] = useState<'login' | 'signup' | 'forgot'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [nome, setNome] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [feedbackSuccess, setFeedbackSuccess] = useState<string | null>(null);

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    clearAuthError();
    setFeedbackSuccess(null);

    if (!email.trim()) return;

    setIsSubmitting(true);
    try {
      if (mode === 'login') {
        await signInWithEmail(email, password);
      } else if (mode === 'signup') {
        const ok = await signUpWithEmail(email, password, nome);
        if (ok) {
          setFeedbackSuccess('Conta criada com sucesso e autenticada no Firebase!');
        }
      } else if (mode === 'forgot') {
        const ok = await sendPasswordReset(email);
        if (ok) {
          setFeedbackSuccess('Link de recuperação enviado para o seu e-mail!');
        }
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 text-slate-100 flex flex-col justify-between p-4 sm:p-6">
      {/* Top Bar with PWA install */}
      <div className="max-w-md w-full mx-auto flex items-center justify-between pt-2">
        <div className="flex items-center gap-2">
          <div className="flex items-center justify-center w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-amber-500 shadow-md">
            <span className="text-base">📅</span>
          </div>
          <span className="text-xs font-bold text-white tracking-wide">
            Lembrete <span className="text-indigo-400">Inteligente</span>
          </span>
        </div>
        <PWAInstallButton />
      </div>

      {/* Main Card */}
      <div className="max-w-md w-full mx-auto my-auto py-6">
        <div className="rounded-3xl bg-slate-900/85 border border-slate-800 p-6 sm:p-7 shadow-2xl backdrop-blur-md">
          {/* Header */}
          <div className="text-center mb-6">
            <div className="relative mx-auto mb-3 flex items-center justify-center w-16 h-16 rounded-3xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-amber-500 shadow-xl shadow-indigo-500/25">
              <span className="text-3xl">📅</span>
              <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-80"></span>
                <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-emerald-500 border-2 border-slate-900"></span>
              </span>
            </div>

            <h1 className="text-xl font-black tracking-tight text-white">
              {mode === 'login' && 'Entrar na sua Agenda'}
              {mode === 'signup' && 'Criar Conta no Firebase'}
              {mode === 'forgot' && 'Recuperar Senha'}
            </h1>
            <p className="mt-1 text-xs text-slate-400">
              {mode === 'login' && 'Acesse seus lembretes sincronizados em tempo real'}
              {mode === 'signup' && 'Cadastre-se para ter sua agenda privada e isolada'}
              {mode === 'forgot' && 'Informe seu e-mail para redefinir a senha'}
            </p>
          </div>

          {/* General Error Banner */}
          {authError && (
            <div className="mb-4 p-3 rounded-2xl bg-rose-950/60 border border-rose-500/40 text-xs text-rose-200 flex items-start gap-2 animate-in fade-in">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="font-semibold">{authError}</p>
                <button
                  onClick={clearAuthError}
                  className="mt-1 text-[11px] underline text-rose-300 hover:text-white"
                >
                  Fechar
                </button>
              </div>
            </div>
          )}

          {/* Success Banner */}
          {feedbackSuccess && (
            <div className="mb-4 p-3 rounded-2xl bg-emerald-950/60 border border-emerald-500/40 text-xs text-emerald-200 flex items-center gap-2 animate-in fade-in">
              <Check className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{feedbackSuccess}</span>
            </div>
          )}

          {/* Form: Email & Password */}
          <form onSubmit={handleEmailAuth} className="space-y-3.5">
            {mode === 'signup' && (
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Seu Nome
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={nome}
                    onChange={(e) => setNome(e.target.value)}
                    placeholder="Ex: Maya Alves"
                    className="w-full bg-slate-800 border border-slate-700 rounded-2xl pl-9 pr-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                  />
                  <User className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                E-mail cadastrado no Firebase
              </label>
              <div className="relative">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="seu-email@dominio.com"
                  className="w-full bg-slate-800 border border-slate-700 rounded-2xl pl-9 pr-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
                <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
              </div>
            </div>

            {mode !== 'forgot' && (
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-semibold text-slate-300">
                    Senha
                  </label>
                  {mode === 'login' && (
                    <button
                      type="button"
                      onClick={() => {
                        setMode('forgot');
                        clearAuthError();
                      }}
                      className="text-[11px] text-indigo-400 hover:text-indigo-300"
                    >
                      Esqueceu?
                    </button>
                  )}
                </div>
                <div className="relative">
                  <input
                    type="password"
                    required
                    minLength={6}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-slate-800 border border-slate-700 rounded-2xl pl-9 pr-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                  />
                  <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                </div>
              </div>
            )}

            {/* Submit Email Button */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-2xl bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-600 hover:to-indigo-700 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 active:scale-[0.98] transition disabled:opacity-50"
            >
              {isSubmitting ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Autenticando...</span>
                </>
              ) : (
                <>
                  <span>
                    {mode === 'login' && 'Entrar com E-mail'}
                    {mode === 'signup' && 'Cadastrar e Entrar'}
                    {mode === 'forgot' && 'Enviar Redefinição'}
                  </span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </>
              )}
            </button>
          </form>

          {/* Mode Switchers */}
          <div className="mt-4 text-center text-xs text-slate-400">
            {mode === 'login' ? (
              <p>
                Não tem uma conta?{' '}
                <button
                  type="button"
                  onClick={() => {
                    setMode('signup');
                    clearAuthError();
                  }}
                  className="font-bold text-indigo-400 hover:underline"
                >
                  Cadastre-se aqui
                </button>
              </p>
            ) : (
              <p>
                Já possui cadastro?{' '}
                <button
                  type="button"
                  onClick={() => {
                    setMode('login');
                    clearAuthError();
                  }}
                  className="font-bold text-indigo-400 hover:underline"
                >
                  Fazer login
                </button>
              </p>
            )}
          </div>


          {/* Security & Project Badge */}
          <div className="mt-5 pt-4 border-t border-slate-800/80 flex items-center justify-center gap-1.5 text-[11px] text-slate-400">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Firebase Auth</span>
            <span className="text-slate-600">&bull;</span>
            <span className="font-mono text-[10px] text-slate-400">lembrete-inteligente-b6cd1</span>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="text-center text-xs text-slate-500 py-2">
        <p>Lembrete Inteligente PWA &bull; Isolamento Multi-Conta</p>
      </footer>
    </div>
  );
};
