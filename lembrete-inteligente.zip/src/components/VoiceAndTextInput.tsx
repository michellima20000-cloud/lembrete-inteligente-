import React, { useState, useRef, useEffect } from 'react';
import {
  Mic,
  MicOff,
  Send,
  CalendarCheck,
  Clock,
  AlertCircle,
  CheckCircle2,
  Sliders,
  Sparkles,
  Zap,
} from 'lucide-react';
import { useReminders } from '../context/RemindersContext';

interface VoiceAndTextInputProps {
  onOpenManualModal: () => void;
}

export const VoiceAndTextInput: React.FC<VoiceAndTextInputProps> = ({ onOpenManualModal }) => {
  const { processAiCommand, isProcessingAi } = useReminders();

  const [inputText, setInputText] = useState('');
  const [selectedAntecedencia, setSelectedAntecedencia] = useState<number>(0);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [speechTranscript, setSpeechTranscript] = useState('');
  const [isAutoScheduling, setIsAutoScheduling] = useState(false);
  const [silenceCountdown, setSilenceCountdown] = useState<number | null>(null);
  const [feedbackMessage, setFeedbackMessage] = useState<{ type: 'sucesso' | 'erro'; text: string } | null>(null);

  const recognitionRef = useRef<any>(null);
  const timerIntervalRef = useRef<any>(null);
  const silenceTimerRef = useRef<any>(null);
  const countdownIntervalRef = useRef<any>(null);
  const latestTranscriptRef = useRef<string>('');
  const selectedAntecedenciaRef = useRef<number>(selectedAntecedencia);
  const isSubmittingRef = useRef<boolean>(false);
  const isRecordingRef = useRef<boolean>(false);

  // Keep antecedência ref synchronized
  useEffect(() => {
    selectedAntecedenciaRef.current = selectedAntecedencia;
  }, [selectedAntecedencia]);

  // Quick suggestions prompt chips
  const sampleSuggestions = [
    'Me lembre amanhã às 12h de verificar o cadastro XPTO',
    'Reunião de alinhamento com a diretoria daqui a 30 minutos',
    'Lembrar daqui a 15 minutos de tomar água',
    'Pagar fatura do cartão hoje às 19:30',
  ];

  const clearSilenceTimers = () => {
    if (silenceTimerRef.current) {
      clearTimeout(silenceTimerRef.current);
      silenceTimerRef.current = null;
    }
    if (countdownIntervalRef.current) {
      clearInterval(countdownIntervalRef.current);
      countdownIntervalRef.current = null;
    }
    setSilenceCountdown(null);
  };

  // Central submission logic (called by manual click, voice silence detection, or stop button)
  const submitReminder = async (textToSubmit: string, isFromVoice: boolean = false) => {
    const clean = textToSubmit.trim();
    if (!clean || clean.length < 3 || isSubmittingRef.current) return;

    isSubmittingRef.current = true;
    setIsAutoScheduling(isFromVoice);
    clearSilenceTimers();

    // Stop recording if still open
    if (recognitionRef.current && isRecordingRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (e) {
        // Ignore
      }
    }
    setIsRecording(false);
    isRecordingRef.current = false;

    try {
      const result = await processAiCommand({
        texto: clean,
        antecedenciaPadrao: selectedAntecedenciaRef.current,
      });

      setInputText('');
      setSpeechTranscript('');
      latestTranscriptRef.current = '';

      const msg = isFromVoice
        ? `⚡ ${result.mensagem_sistema || 'Lembrete agendado automaticamente por voz!'}`
        : (result.mensagem_sistema || 'Lembrete agendado com sucesso!');

      setFeedbackMessage({
        type: 'sucesso',
        text: msg,
      });
      setTimeout(() => setFeedbackMessage(null), 6000);
    } catch (err: any) {
      setFeedbackMessage({
        type: 'erro',
        text: err?.message || 'Não foi possível agendar o lembrete. Tente novamente.',
      });
    } finally {
      isSubmittingRef.current = false;
      setIsAutoScheduling(false);
      setSilenceCountdown(null);
    }
  };

  // Initialize native Browser Web Speech Recognition
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const SpeechRecognition =
        (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

      if (SpeechRecognition) {
        const recognition = new SpeechRecognition();
        recognition.continuous = true;
        recognition.interimResults = true;
        recognition.lang = 'pt-BR';

        recognition.onresult = (event: any) => {
          let current = '';
          for (let i = 0; i < event.results.length; i++) {
            current += event.results[i][0].transcript;
          }
          const cleanTranscript = current.trim();
          if (!cleanTranscript) return;

          latestTranscriptRef.current = cleanTranscript;
          setSpeechTranscript(cleanTranscript);
          setInputText(cleanTranscript);

          // Voice auto-scheduling:
          // When speech is recognized, reset silence detection countdown (1.4s of silence = auto schedule)
          clearSilenceTimers();

          if (cleanTranscript.length >= 4 && !isSubmittingRef.current) {
            setSilenceCountdown(2);
            let remaining = 2;
            countdownIntervalRef.current = setInterval(() => {
              remaining -= 1;
              if (remaining <= 0) {
                if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
                setSilenceCountdown(null);
              } else {
                setSilenceCountdown(remaining);
              }
            }, 700);

            silenceTimerRef.current = setTimeout(() => {
              const textToAutoSubmit = latestTranscriptRef.current.trim();
              if (textToAutoSubmit.length >= 4 && !isSubmittingRef.current) {
                submitReminder(textToAutoSubmit, true);
              }
            }, 1400);
          }
        };

        recognition.onerror = (event: any) => {
          console.warn('Reconhecimento de voz:', event.error);
          if (event.error !== 'no-speech') {
            setIsRecording(false);
            isRecordingRef.current = false;
            clearSilenceTimers();
          }
        };

        recognition.onend = () => {
          setIsRecording(false);
          isRecordingRef.current = false;
          // If ended and there is transcript captured that hasn't been submitted yet, auto-schedule!
          const textToAutoSubmit = latestTranscriptRef.current.trim();
          if (textToAutoSubmit.length >= 4 && !isSubmittingRef.current) {
            submitReminder(textToAutoSubmit, true);
          }
        };

        recognitionRef.current = recognition;
      }
    }

    return () => {
      clearSilenceTimers();
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {}
      }
    };
  }, []);

  // Timer for recording duration
  useEffect(() => {
    if (isRecording) {
      setRecordingSeconds(0);
      timerIntervalRef.current = setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    }
    return () => {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    };
  }, [isRecording]);

  const startVoiceCapture = () => {
    setFeedbackMessage(null);
    setSpeechTranscript('');
    latestTranscriptRef.current = '';
    clearSilenceTimers();

    if (!recognitionRef.current) {
      setFeedbackMessage({
        type: 'erro',
        text: 'Seu navegador não suporta a Web Speech API. Digite o lembrete no campo de texto.',
      });
      return;
    }

    try {
      recognitionRef.current.start();
      setIsRecording(true);
      isRecordingRef.current = true;
    } catch (e) {
      console.warn('Erro ao iniciar reconhecimento:', e);
      setIsRecording(false);
      isRecordingRef.current = false;
    }
  };

  const stopVoiceCapture = () => {
    // When stopping manually (clicking mic or finish button), immediately submit if text exists!
    const textToSubmit = (latestTranscriptRef.current || inputText).trim();
    if (textToSubmit.length >= 4 && !isSubmittingRef.current) {
      submitReminder(textToSubmit, true);
    } else {
      setIsRecording(false);
      isRecordingRef.current = false;
      clearSilenceTimers();
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {}
      }
    }
  };

  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const textToSubmit = inputText.trim();
    if (!textToSubmit) return;
    await submitReminder(textToSubmit, false);
  };

  const selectSuggestion = (text: string) => {
    setInputText(text);
  };

  const quickScheduleSuggestion = (text: string) => {
    setInputText(text);
    submitReminder(text, false);
  };

  return (
    <section className="bg-slate-900/60 rounded-3xl p-4 sm:p-5 border border-slate-800 shadow-xl backdrop-blur-sm">
      {/* Header Info */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 mb-3">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-xl bg-indigo-500/20 text-indigo-400">
            <CalendarCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-white tracking-wide">
                Agendamento por Voz ou Texto
              </h2>
              {/* Hands-free badge */}
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-[10px] font-semibold text-emerald-300">
                <Zap className="w-2.5 h-2.5 text-emerald-400" />
                Auto-agenda ao falar
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              Fale seu lembrete que o sistema agenda automaticamente sem precisar clicar
            </p>
          </div>
        </div>

        <button
          onClick={onOpenManualModal}
          className="self-start sm:self-auto flex items-center gap-1 text-[11px] font-semibold text-slate-400 hover:text-indigo-300 py-1 px-2.5 rounded-xl bg-slate-800/80 border border-slate-700/60 transition"
          title="Agendamento manual por data e hora"
        >
          <Sliders className="w-3 h-3 text-indigo-400" />
          Manual
        </button>
      </div>

      {/* Main Input Box */}
      <form onSubmit={handleSubmit} className="relative">
        <div className={`relative rounded-2xl bg-slate-800/90 border transition shadow-inner ${
          isRecording
            ? 'border-rose-500/60 ring-2 ring-rose-500/20'
            : isAutoScheduling
            ? 'border-emerald-500/60 ring-2 ring-emerald-500/20'
            : 'border-slate-700 focus-within:border-indigo-500'
        }`}>
          <textarea
            rows={2}
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder='Fale ou digite: "Me lembre amanhã às 12h de verificar o cadastro"...'
            disabled={isProcessingAi || isAutoScheduling}
            className="w-full bg-transparent px-4 py-3 text-sm text-white placeholder-slate-400 focus:outline-none resize-none disabled:opacity-60"
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSubmit();
              }
            }}
          />

          {/* Bottom Bar inside Input */}
          <div className="flex flex-wrap items-center justify-between gap-2 px-3 pb-2.5 pt-1 border-t border-slate-700/40">
            {/* Antecedência Selector */}
            <div className="flex items-center gap-1.5 overflow-x-auto py-0.5 scrollbar-none">
              <span className="text-[11px] font-medium text-slate-400 flex items-center gap-1 shrink-0">
                <Clock className="w-3 h-3 text-indigo-400" />
                Avisar:
              </span>
              {[
                { label: 'No horário', val: 0 },
                { label: '5m antes', val: 5 },
                { label: '10m antes', val: 10 },
                { label: '15m antes', val: 15 },
                { label: '30m antes', val: 30 },
              ].map((opt) => (
                <button
                  key={opt.val}
                  type="button"
                  onClick={() => setSelectedAntecedencia(opt.val)}
                  className={`px-2 py-0.5 rounded-full text-[10px] font-semibold transition shrink-0 ${
                    selectedAntecedencia === opt.val
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'bg-slate-700/60 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>

            {/* Actions: Mic & Submit */}
            <div className="flex items-center gap-2 shrink-0">
              {/* Voice button (Native Web Speech API with Auto-scheduling) */}
              <button
                type="button"
                onClick={isRecording ? stopVoiceCapture : startVoiceCapture}
                disabled={isProcessingAi || isAutoScheduling}
                className={`relative p-2.5 rounded-xl flex items-center justify-center transition-all ${
                  isRecording
                    ? 'bg-rose-600 text-white shadow-lg shadow-rose-600/40 scale-105 animate-pulse'
                    : isAutoScheduling
                    ? 'bg-emerald-600 text-white animate-spin'
                    : 'bg-indigo-950/80 text-indigo-300 border border-indigo-500/40 hover:bg-indigo-900 active:scale-95'
                }`}
                title={
                  isRecording
                    ? 'Parar gravação (agendará imediatamente)'
                    : 'Falar lembrete (agenda automaticamente)'
                }
              >
                {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                {isRecording && (
                  <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-500"></span>
                  </span>
                )}
              </button>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isProcessingAi || isAutoScheduling || !inputText.trim()}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-600 hover:to-indigo-700 text-white text-xs font-bold shadow-md shadow-indigo-600/30 transition disabled:opacity-40 disabled:cursor-not-allowed active:scale-95"
              >
                {isProcessingAi || isAutoScheduling ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>Agendando...</span>
                  </>
                ) : (
                  <>
                    <span>Agendar</span>
                    <Send className="w-3.5 h-3.5" />
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </form>

      {/* Recording in progress overlay bar with live auto-schedule status */}
      {isRecording && (
        <div className="mt-2.5 p-3 rounded-2xl bg-rose-950/50 border border-rose-500/40 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2.5 text-xs text-rose-200 animate-in fade-in">
          <div className="flex items-center gap-2.5 flex-1 min-w-0">
            <span className="flex h-3 w-3 relative shrink-0">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-rose-500"></span>
            </span>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className="font-bold text-white">Ouvindo pelo microfone ({recordingSeconds}s)</span>
                {speechTranscript && (
                  <span className="px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-semibold flex items-center gap-0.5">
                    <Sparkles className="w-2.5 h-2.5 text-emerald-400" />
                    Auto-agendamento ativo
                  </span>
                )}
              </div>
              <p className="text-[11px] text-rose-200/90 truncate mt-0.5">
                {speechTranscript ? `"${speechTranscript}"` : 'Pode falar seu lembrete agora...'}
              </p>
              {speechTranscript && (
                <p className="text-[10px] text-emerald-300 font-medium mt-0.5">
                  ⚡ Ao terminar de falar, o agendamento será feito automaticamente!
                </p>
              )}
            </div>
          </div>

          <div className="flex items-center gap-1.5 self-end sm:self-auto shrink-0">
            <button
              onClick={stopVoiceCapture}
              className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-[11px] shadow-md transition flex items-center gap-1 active:scale-95"
              title="Finalizar fala e agendar agora"
            >
              <Zap className="w-3 h-3 text-amber-300" />
              <span>Concluir e Agendar</span>
            </button>
          </div>
        </div>
      )}

      {/* Auto-scheduling in progress indicator */}
      {isAutoScheduling && !isRecording && (
        <div className="mt-2.5 p-3 rounded-2xl bg-indigo-950/60 border border-indigo-500/40 flex items-center gap-2.5 text-xs text-indigo-200 animate-in fade-in">
          <div className="w-4 h-4 border-2 border-indigo-400/30 border-t-indigo-400 rounded-full animate-spin shrink-0" />
          <div>
            <p className="font-bold text-white flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-400 animate-bounce" />
              Agendando automaticamente por voz...
            </p>
            <p className="text-[11px] text-indigo-300/80">Identificando horário, urgência e salvando seu lembrete.</p>
          </div>
        </div>
      )}

      {/* Confirmation / Error feedback banner */}
      {feedbackMessage && (
        <div
          className={`mt-2.5 p-3 rounded-2xl flex items-start gap-2.5 text-xs animate-in fade-in slide-in-from-top-1 ${
            feedbackMessage.type === 'sucesso'
              ? 'bg-emerald-950/70 border border-emerald-500/50 text-emerald-200'
              : 'bg-rose-950/70 border border-rose-500/50 text-rose-200'
          }`}
        >
          {feedbackMessage.type === 'sucesso' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
          ) : (
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
          )}
          <div className="flex-1">
            <p className="font-semibold text-white">
              {feedbackMessage.type === 'sucesso' ? 'Lembrete Confirmado!' : 'Aviso do Sistema'}
            </p>
            <p className="text-[11px] mt-0.5 text-slate-200">{feedbackMessage.text}</p>
          </div>
        </div>
      )}

      {/* Suggestion Chips */}
      <div className="mt-3">
        <div className="flex items-center justify-between mb-1.5">
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
            <span>💡 Exemplos Rápidos:</span>
          </p>
          <span className="text-[10px] text-slate-400">
            Clique para preencher ou use o ícone ⚡ para agendar direto
          </span>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {sampleSuggestions.map((sug, i) => (
            <div
              key={i}
              className="inline-flex items-center rounded-xl bg-slate-800/80 border border-slate-700/60 overflow-hidden text-slate-300 hover:text-white transition group"
            >
              <button
                type="button"
                onClick={() => selectSuggestion(sug)}
                className="text-left text-[11px] px-2.5 py-1 hover:bg-slate-700/80 transition"
                title="Preencher campo de texto"
              >
                "{sug}"
              </button>
              <button
                type="button"
                onClick={() => quickScheduleSuggestion(sug)}
                disabled={isProcessingAi || isAutoScheduling}
                className="px-1.5 py-1 text-indigo-400 hover:text-indigo-200 hover:bg-indigo-600/30 border-l border-slate-700/60 transition"
                title="Agendar imediatamente este exemplo"
              >
                <Zap className="w-3 h-3 text-amber-400" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
