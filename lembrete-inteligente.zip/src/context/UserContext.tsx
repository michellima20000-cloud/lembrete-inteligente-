import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserProfile } from '../types';
import { auth, googleProvider } from '../lib/firebase';
import {
  onAuthStateChanged,
  signInWithPopup,
  signOut as fbSignOut,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  updateProfile,
  User as FirebaseUser,
} from 'firebase/auth';

interface UserContextType {
  currentUser: UserProfile | null;
  firebaseUser: FirebaseUser | null;
  isAuthenticated: boolean;
  isAuthReady: boolean;
  signInWithGoogle: () => Promise<void>;
  signInWithEmail: (email: string, pass: string) => Promise<boolean>;
  signUpWithEmail: (email: string, pass: string, name?: string) => Promise<boolean>;
  sendPasswordReset: (email: string) => Promise<boolean>;
  signOutFirebase: () => Promise<void>;
  authError: string | null;
  unauthorizedDomain: boolean;
  clearAuthError: () => void;
}

const UserContext = createContext<UserContextType | null>(null);

export const UserProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [unauthorizedDomain, setUnauthorizedDomain] = useState(false);

  // Clean out legacy mock data from localStorage
  useEffect(() => {
    try {
      localStorage.removeItem('lembrete_users_profiles');
      localStorage.removeItem('lembrete_active_user_id');
      localStorage.removeItem('lembretes_isolated_user_maya');
      localStorage.removeItem('lembretes_isolated_user_trabalho');
      localStorage.removeItem('lembretes_isolated_user_pessoal');
    } catch (e) {
      // Ignore
    }
  }, []);

  // Listen to authoritative Firebase Auth state
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(
      auth,
      async (user) => {
        setFirebaseUser(user);
        if (user) {
          const profile: UserProfile = {
            id: user.uid,
            nome: user.displayName || user.email?.split('@')[0] || 'Usuário',
            email: user.email || undefined,
            avatarCor: '#4f46e5',
            criado_em: user.metadata.creationTime || new Date().toISOString(),
          };
          setCurrentUser(profile);

          // Register in backend
          fetch('/api/users', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(profile),
          }).catch(() => {});
        } else {
          setCurrentUser(null);
        }
        setIsAuthReady(true);
      },
      (error) => {
        console.error('Firebase Auth state error:', error);
        setIsAuthReady(true);
      }
    );

    return () => unsubscribe();
  }, []);

  const signInWithGoogle = async () => {
    setAuthError(null);
    setUnauthorizedDomain(false);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err: any) {
      console.warn('Google Sign-in status:', err);
      if (err.code === 'auth/unauthorized-domain') {
        setUnauthorizedDomain(true);
        setAuthError(
          'O domínio deste app ainda não está autorizado para login Google no Console do Firebase. Use o login por E-mail e Senha abaixo (já funcionando) ou autorize o domínio no Firebase.'
        );
      } else if (err.code === 'auth/popup-closed-by-user') {
        setAuthError('O login com Google foi cancelado antes de concluir.');
      } else if (err.code === 'auth/popup-blocked') {
        setAuthError('O navegador bloqueou a janela de pop-up. Por favor, permita pop-ups.');
      } else {
        setAuthError(err.message || 'Falha ao autenticar com o Google.');
      }
    }
  };

  const signInWithEmail = async (email: string, pass: string): Promise<boolean> => {
    setAuthError(null);
    setUnauthorizedDomain(false);
    try {
      await signInWithEmailAndPassword(auth, email.trim(), pass);
      return true;
    } catch (err: any) {
      console.warn('Email sign-in error:', err);
      if (err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
        setAuthError('E-mail ou senha incorretos. Verifique suas credenciais.');
      } else if (err.code === 'auth/invalid-email') {
        setAuthError('Formato de e-mail inválido.');
      } else if (err.code === 'auth/user-disabled') {
        setAuthError('Esta conta de usuário foi desativada.');
      } else {
        setAuthError(err.message || 'Falha ao autenticar com e-mail e senha.');
      }
      return false;
    }
  };

  const signUpWithEmail = async (email: string, pass: string, name?: string): Promise<boolean> => {
    setAuthError(null);
    setUnauthorizedDomain(false);
    try {
      const cred = await createUserWithEmailAndPassword(auth, email.trim(), pass);
      if (name && cred.user) {
        await updateProfile(cred.user, { displayName: name.trim() });
      }
      return true;
    } catch (err: any) {
      console.warn('Email sign-up error:', err);
      if (err.code === 'auth/email-already-in-use') {
        setAuthError('Este e-mail já está cadastrado. Tente entrar ou recuperar a senha.');
      } else if (err.code === 'auth/weak-password') {
        setAuthError('A senha deve ter pelo menos 6 caracteres.');
      } else if (err.code === 'auth/invalid-email') {
        setAuthError('Formato de e-mail inválido.');
      } else {
        setAuthError(err.message || 'Falha ao cadastrar com e-mail e senha.');
      }
      return false;
    }
  };

  const sendPasswordReset = async (email: string): Promise<boolean> => {
    setAuthError(null);
    try {
      await sendPasswordResetEmail(auth, email.trim());
      return true;
    } catch (err: any) {
      console.warn('Password reset error:', err);
      setAuthError(err.message || 'Falha ao enviar e-mail de redefinição de senha.');
      return false;
    }
  };

  const signOutFirebase = async () => {
    try {
      await fbSignOut(auth);
      setFirebaseUser(null);
      setCurrentUser(null);
    } catch (err: any) {
      console.error('Erro ao sair da conta:', err);
    }
  };

  const clearAuthError = () => {
    setAuthError(null);
    setUnauthorizedDomain(false);
  };

  return (
    <UserContext.Provider
      value={{
        currentUser,
        firebaseUser,
        isAuthenticated: !!firebaseUser && !!currentUser,
        isAuthReady,
        signInWithGoogle,
        signInWithEmail,
        signUpWithEmail,
        sendPasswordReset,
        signOutFirebase,
        authError,
        unauthorizedDomain,
        clearAuthError,
      }}
    >
      {children}
    </UserContext.Provider>
  );
};

export const useUser = () => {
  const ctx = useContext(UserContext);
  if (!ctx) throw new Error('useUser must be used within UserProvider');
  return ctx;
};
