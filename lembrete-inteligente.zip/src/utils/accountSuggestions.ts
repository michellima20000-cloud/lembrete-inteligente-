import { Lembrete } from '../types';

export interface AccountQuickSuggestion {
  id: string;
  texto: string;
  categoria: string;
  origem: 'recente' | 'hábito' | 'sugestão';
}

export interface LiveSignalingInfo {
  tituloDetectado: string;
  dataHoraDetectada: string;
  categoriaDetectada: string;
  urgenciaDetectada: 'baixa' | 'media' | 'alta';
  prontoParaAgendar: boolean;
}

const STORAGE_PREFIX = 'lembrete_account_guide_';

// Save a successful voice/text query to the user's account local history (zero network data usage)
export function recordAccountQuery(userId: string, queryText: string) {
  if (!userId || !queryText.trim()) return;
  try {
    const key = STORAGE_PREFIX + userId;
    const existingRaw = localStorage.getItem(key);
    let history: string[] = existingRaw ? JSON.parse(existingRaw) : [];

    const clean = queryText.trim();
    // Keep unique, most recent first, max 10
    history = [clean, ...history.filter((item) => item.toLowerCase() !== clean.toLowerCase())].slice(0, 10);
    localStorage.setItem(key, JSON.stringify(history));
  } catch (e) {
    // Ignore storage issues
  }
}

// Generate personalized quick examples according to the active user's account and reminders
export function getAccountSuggestions(
  userId: string,
  userName: string,
  reminders: Lembrete[]
): AccountQuickSuggestion[] {
  const suggestions: AccountQuickSuggestion[] = [];

  // 1. Check user's account history
  let accountHistory: string[] = [];
  try {
    const raw = localStorage.getItem(STORAGE_PREFIX + userId);
    if (raw) {
      accountHistory = JSON.parse(raw);
    }
  } catch (e) {
    accountHistory = [];
  }

  // Add up to 2 most recent commands used by this account
  accountHistory.slice(0, 2).forEach((cmd, idx) => {
    suggestions.push({
      id: `hist_${idx}`,
      texto: cmd,
      categoria: 'Recente da Conta',
      origem: 'recente',
    });
  });

  // 2. Derive personalized examples only from the user's own actual reminders (if any exist)
  if (reminders && reminders.length > 0) {
    reminders.slice(0, 4).forEach((r, idx) => {
      // Don't duplicate if already in suggestions
      if (suggestions.length < 4 && !suggestions.some((s) => s.texto.toLowerCase() === r.titulo.toLowerCase())) {
        suggestions.push({
          id: `hab_${r.id || idx}`,
          texto: r.titulo,
          categoria: r.categoria || 'Geral',
          origem: 'hábito',
        });
      }
    });
  }

  // Notice: No hardcoded fallback dummy suggestions!
  // If the user hasn't started using the system yet, this returns []
  // so the screen remains completely clean and uncluttered.
  return suggestions.slice(0, 4);
}

// Client-side instant live signaling parser (0 data usage, 0 API calls)
export function parseLiveSignaling(inputText: string): LiveSignalingInfo | null {
  if (!inputText || inputText.trim().length < 2) return null;

  const text = inputText.trim();
  const lower = text.toLowerCase();

  // Category detection
  let categoria = 'Geral';
  if (/remédio|remedio|médic|medico|exame|consulta|água|treino|academia|saúde|saude/.test(lower)) {
    categoria = 'Saúde';
  } else if (/reunião|reuniao|cliente|relatório|relatorio|trabalho|projeto|cadastro|sistema|apresentação/.test(lower)) {
    categoria = 'Trabalho';
  } else if (/pagar|pago|fatura|boleto|banco|dinheiro|pix|cartão|cartao|conta/.test(lower)) {
    categoria = 'Finanças';
  } else if (/estudo|estudar|prova|aula|curso|livro|faculdade/.test(lower)) {
    categoria = 'Estudos';
  }

  // Urgency detection
  let urgencia: 'baixa' | 'media' | 'alta' = 'media';
  if (/urgente|emergência|emergencia|imediat|importante|não esquecer/.test(lower)) {
    urgencia = 'alta';
  } else if (/quando der|com calma|opcional/.test(lower)) {
    urgencia = 'baixa';
  }

  // Date/Time detection
  let dataHoraDetectada = '';
  const timeRegex = /(?:às|as|ás|de|para)?\s*(\d{1,2})(?:[h:](\d{2})?|h\b)/i;
  const matchTime = text.match(timeRegex);

  const relativeRegex = /daqui\s+a\s+(\d+)\s*(minutos?|min|horas?|h)/i;
  const matchRelative = text.match(relativeRegex);

  if (matchRelative) {
    const val = parseInt(matchRelative[1], 10);
    const unit = matchRelative[2].toLowerCase();
    dataHoraDetectada = `Em ${val} ${unit.startsWith('h') ? 'hora(s)' : 'minuto(s)'}`;
  } else if (matchTime) {
    const hora = matchTime[1];
    const minuto = matchTime[2] || '00';
    let dia = 'Hoje';
    if (/amanhã|amanha/i.test(lower)) {
      dia = 'Amanhã';
    } else if (/depois de amanhã/i.test(lower)) {
      dia = 'Depois de amanhã';
    } else if (/segunda/i.test(lower)) dia = 'Segunda-feira';
    else if (/terça|terca/i.test(lower)) dia = 'Terça-feira';
    else if (/quarta/i.test(lower)) dia = 'Quarta-feira';
    else if (/quinta/i.test(lower)) dia = 'Quinta-feira';
    else if (/sexta/i.test(lower)) dia = 'Sexta-feira';
    else if (/sábado|sabado/i.test(lower)) dia = 'Sábado';
    else if (/domingo/i.test(lower)) dia = 'Domingo';

    dataHoraDetectada = `${dia} às ${hora.padStart(2, '0')}:${minuto.padStart(2, '0')}`;
  } else if (/hoje/i.test(lower)) {
    dataHoraDetectada = 'Hoje (horário a confirmar)';
  } else if (/amanhã|amanha/i.test(lower)) {
    dataHoraDetectada = 'Amanhã (horário padrão 09:00)';
  }

  // Clean title
  let titulo = text
    .replace(/^me\s+lembre\s+(de\s+)?/i, '')
    .replace(/^lembrar\s+(de\s+)?/i, '')
    .replace(/^agendar\s+/i, '')
    .trim();

  return {
    tituloDetectado: titulo || text,
    dataHoraDetectada: dataHoraDetectada || 'Horário padrão (hoje/próxima hora)',
    categoriaDetectada: categoria,
    urgenciaDetectada: urgencia,
    prontoParaAgendar: text.length >= 3,
  };
}
