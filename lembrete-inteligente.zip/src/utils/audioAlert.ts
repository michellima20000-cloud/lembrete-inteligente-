// Web Audio API Synthesizer for notifications and alarms
// 100% native Web Audio API — Zero data consumption (no external MP3/audio files to download)
// Works on iOS, Android, and Desktop browsers.

class SoundAlertManager {
  private audioCtx: AudioContext | null = null;
  private isSoundEnabled = true;
  private alarmInterval: any = null;
  private isRingingContinuous = false;

  constructor() {
    // AudioContext is initialized on first user interaction to comply with browser autoplay policies
  }

  private getAudioContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.audioCtx) {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        this.audioCtx = new AudioContextClass();
      }
    }
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
    return this.audioCtx;
  }

  public setSoundEnabled(enabled: boolean) {
    this.isSoundEnabled = enabled;
    if (!enabled) {
      this.stopContinuousAlarm();
    }
  }

  public getSoundEnabled(): boolean {
    return this.isSoundEnabled;
  }

  public isContinuousAlarmRinging(): boolean {
    return this.isRingingContinuous;
  }

  // Soft reminder ping (two harmonic chimes)
  public playChime() {
    if (!this.isSoundEnabled) return;
    try {
      const ctx = this.getAudioContext();
      if (!ctx) return;

      const now = ctx.currentTime;
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();

      osc1.type = 'sine';
      osc2.type = 'triangle';

      osc1.frequency.setValueAtTime(587.33, now); // D5
      osc1.frequency.exponentialRampToValueAtTime(880, now + 0.15); // A5

      osc2.frequency.setValueAtTime(880, now + 0.15);
      osc2.frequency.exponentialRampToValueAtTime(1174.66, now + 0.35); // D6

      gain.gain.setValueAtTime(0.3, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.6);

      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(ctx.destination);

      osc1.start(now);
      osc2.start(now + 0.15);
      osc1.stop(now + 0.35);
      osc2.stop(now + 0.6);

      if ('vibrate' in navigator) {
        navigator.vibrate([150, 80, 150]);
      }
    } catch (e) {
      console.warn('Audio alert could not play:', e);
    }
  }

  // Urgent single Alarm (multi-tone alert bell)
  public playAlarm() {
    if (!this.isSoundEnabled) return;
    try {
      const ctx = this.getAudioContext();
      if (!ctx) return;

      const now = ctx.currentTime;
      const notes = [659.25, 880, 1046.5, 1318.5]; // E5, A5, C6, E6

      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now + idx * 0.14);

        gain.gain.setValueAtTime(0.45, now + idx * 0.14);
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.14 + 0.45);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(now + idx * 0.14);
        osc.stop(now + idx * 0.14 + 0.5);
      });

      if ('vibrate' in navigator) {
        navigator.vibrate([350, 150, 350, 150, 600]);
      }
    } catch (e) {
      console.warn('Alarm audio could not play:', e);
    }
  }

  // Continuous Alarm: keeps ringing directly until user interacts / clicks to view reminder
  public startContinuousAlarm() {
    if (!this.isSoundEnabled) return;
    if (this.isRingingContinuous) return;

    this.isRingingContinuous = true;
    this.playAlarm();

    // Clear any previous interval
    if (this.alarmInterval) {
      clearInterval(this.alarmInterval);
    }

    // Repeat alarm chime every 2.6 seconds non-stop
    this.alarmInterval = setInterval(() => {
      if (!this.isRingingContinuous || !this.isSoundEnabled) {
        this.stopContinuousAlarm();
        return;
      }
      this.playAlarm();
    }, 2600);
  }

  // Stop the continuous alarm immediately
  public stopContinuousAlarm() {
    this.isRingingContinuous = false;
    if (this.alarmInterval) {
      clearInterval(this.alarmInterval);
      this.alarmInterval = null;
    }
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(0);
      } catch (e) {
        // Ignore
      }
    }
  }

  // Success Confirmation Sound
  public playSuccess() {
    if (!this.isSoundEnabled) return;
    try {
      const ctx = this.getAudioContext();
      if (!ctx) return;

      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(523.25, now); // C5
      osc.frequency.exponentialRampToValueAtTime(1046.5, now + 0.2); // C6

      gain.gain.setValueAtTime(0.25, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.3);

      if ('vibrate' in navigator) {
        navigator.vibrate(80);
      }
    } catch (e) {
      console.warn('Success sound could not play:', e);
    }
  }
}

export const soundAlert = new SoundAlertManager();
